#!/usr/bin/env python3
from typing import List, Dict, Optional

class RSAValidator:
    def __init__(self, n_hex: str = None, s_hex: str = None, e: int = 65537):
        self.e = e
        self.N = int(n_hex, 16) if n_hex else None
        self.N_hex = n_hex.upper() if n_hex else None
        self.S = int(s_hex, 16) if s_hex else None
        self.S_hex = s_hex.upper() if s_hex else None

    def validate_input_lengths(self) -> Dict[str, bool]:
        results = {}
        if self.N_hex:
            results['N_length'] = len(self.N_hex)
            results['N_valid'] = len(self.N_hex) == 512
        if self.S_hex:
            results['S_length'] = len(self.S_hex)
            results['S_valid'] = len(self.S_hex) == 512
        return results

    def calculate_verification(self, signature: int, modulus: int) -> int:
        return pow(signature, self.e, modulus)

    def is_in_standard_range(self, signature: int, modulus: int) -> bool:
        return 0 <= signature < modulus

    def generate_variant_signatures(self, k_values: List[int] = None) -> List[Dict]:
        if k_values is None:
            k_values = [0, 1, 2, 3, 10, 100]
        if self.N is None or self.S is None:
            raise ValueError("请先设置N和S的值")
        original_verify = self.calculate_verification(self.S, self.N)
        results = []
        for k in k_values:
            s_prime = self.S + k * self.N
            verify_result = self.calculate_verification(s_prime, self.N)
            s_prime_hex = hex(s_prime)[2:].upper().zfill(512)
            results.append({
                'k': k,
                's_prime_int': s_prime,
                's_prime_hex': s_prime_hex,
                'verification_int': verify_result,
                'verification_hex': hex(verify_result)[2:].upper(),
                'matches_original': verify_result == original_verify,
                'in_standard_range': self.is_in_standard_range(s_prime, self.N),
                'formula': f"S' = S + {k}*N" if k != 0 else "S' = S"
            })
        return results

    def format_for_fastboot(self, results: List[Dict]) -> str:
        lines = ["=" * 80, "Fastboot 解锁命令", "=" * 80]
        for r in results:
            if r['k'] <= 3:
                lines.append(f"\n# k={r['k']}: {r['formula']}")
                lines.append(f"# 验证通过: {r['matches_original']}")
                lines.append(f"# 标准范围: {'是' if r['in_standard_range'] else '否'}")
                lines.append(f"fastboot stage {r['s_prime_hex']}")
        return "\n".join(lines)

    def generate_summary_report(self, results: List[Dict]) -> str:
        total = len(results)
        valid = len([r for r in results if r['in_standard_range']])
        all_pass = all(r['matches_original'] for r in results)
        report = (
            f"\n{'='*80}\n"
            f"RSA签名验证摘要报告 | 小米Wayne设备实测\n"
            f"{'='*80}\n"
            f"公钥模数 N (前64位): {self.N_hex[:64]}...\n"
            f"原始签名 S (前64位): {self.S_hex[:64]}...\n"
            f"\n📊 实测统计:\n"
            f"  总测试签名数: {total}\n"
            f"  标准范围(0≤S'<N): {valid}\n"
            f"  超出标准范围: {total - valid}\n"
            f"  全量数学验证通过: {all_pass}\n"
            f"\n🔬 核心结论:\n"
            f"  对任意整数k，S'=S+k*N 满足 pow(S',e,N)=pow(S,e,N)\n"
            f"  解锁签名非唯一，仅受系统范围校验限制\n"
        )
        return report

def xda_experiment_mode():
    print("=" * 80)
    print("🧪 XDA EXPERIMENT MODE | 小米Wayne设备实测版")
    print("=" * 80)
    print("✅ 真实设备N/S直填，验证RSA同余签名族理论")
    print("🔗 理论核心：S' = S + k*N 数学层面永久合法\n")

    N_HEX = "951856E1DB5BC0FC2E7027BEEE26D9057E94762B61039B0ED17904815D4957BF23B142A19F259DBAD3CCBA4F917BE6C20806DB98E0216219377F0B2BD61989541C141464B6709AF0D014D4DE82BEFB3FF6B957A5A921B065608B20A92D510CD37B0AA92BBF0FCF8BD"
    S_HEX = "854E36A3FEC4C71EF4A4A73F30561EFBCB3061DB4AA28DE4D9A1D11CAEDDE9AB01F0D3E881EBE153BF32F541560FF2CB348597179F92C4326E160BD3EFC8E6DCDFBB6F1F66FD36D90511CF971E964F9B08EA9EC562A2EFE7788ADED4A4D3D8CC4E2A8AB3F26246850CEA1D2BB57DD5421901E451A3A16CDCF8B1E28E82C7FAB37660CEDE8574392A8CFE84217EF2747E6678CEAE0D30A43304C6D159D5F86D5BF68149DB304A8BD6C4B0AF172770A44F49E8261FD30FC54D38303FD62E20B8333A9A252E239B6D0FF6D936883A04B17A6999E1E81DA753E772BD94D427A8121D5C67E48D6974782E71FBB0E76FE967BA19BFA1813B8929A69ECFE7555101FBB3"

    validator = RSAValidator(N_HEX, S_HEX)
    check = validator.validate_input_lengths()
    print(f"📌 设备参数验证:")
    print(f"  N长度(512位): {check['N_valid']} | S长度(512位): {check['S_valid']}\n")
    
    print("⚙️  生成变体签名并验证...\n")
    results = validator.generate_variant_signatures()
    print(validator.format_for_fastboot(results))
    print(validator.generate_summary_report(results))
    print("=" * 80)
    print("📢 欢迎XDA大佬基于此实测继续研究！")
    return validator, results

def main():
    xda_experiment_mode()

if __name__ == "__main__":
    main()
