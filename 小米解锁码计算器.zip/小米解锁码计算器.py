#!/usr/bin/env python3
import hashlib
import sys
from typing import List, Dict, Optional

class RSAValidator:
    def __init__(self, n_hex: str = None, s_hex: str = None, e: int = 65537):
        self.e = e
        if n_hex:
            self.N = int(n_hex, 16)
            self.N_hex = n_hex.upper()
        else:
            self.N = None
            self.N_hex = None
        if s_hex:
            self.S = int(s_hex, 16)
            self.S_hex = s_hex.upper()
        else:
            self.S = None
            self.S_hex = None

    def validate_input_lengths(self) -> Dict[str, bool]:
        results = {}
        if self.N_hex:
            results['N_length'] = len(self.N_hex)
            results['N_valid'] = len(self.N_hex) == 512
        if self.S_hex:
            results['S_length'] = len(self.S_hex)
            results['S_valid'] = len(self.S_hex) == 512
        return results

    def calculate_verification(self, signature: int, modulus: int) -> int:
        return pow(signature, self.e, modulus)

    def is_in_standard_range(self, signature: int, modulus: int) -> bool:
        return 0 <= signature < modulus

    def generate_variant_signatures(self, k_values: List[int] = None) -> List[Dict]:
        if k_values is None:
            k_values = [0, 1, 2, 3, 10, 100]
        if self.N is None or self.S is None:
            raise ValueError("请先设置N和S的值")
        original_verify = self.calculate_verification(self.S, self.N)
        results = []
        for k in k_values:
            s_prime = self.S + k * self.N
            verify_result = self.calculate_verification(s_prime, self.N)
            s_prime_hex = hex(s_prime)[2:].upper().zfill(512)
            result = {
                'k': k,
                's_prime_int': s_prime,
                's_prime_hex': s_prime_hex,
                'verification_int': verify_result,
                'verification_hex': hex(verify_result)[2:].upper(),
                'matches_original': verify_result == original_verify,
                'in_standard_range': self.is_in_standard_range(s_prime, self.N),
                'formula': f"S' = S + {k}*N" if k != 0 else "S' = S"
            }
            results.append(result)
        return results

    def format_for_fastboot(self, results: List[Dict]) -> str:
        output_lines = []
        output_lines.append("=" * 80)
        output_lines.append("Fastboot 解锁命令")
        output_lines.append("=" * 80)
        for result in results:
            if result['k'] <= 3:
                output_lines.append(f"\n# k={result['k']}: {result['formula']}")
                output_lines.append(f"# 验证通过: {result['matches_original']}")
                output_lines.append(f"# 标准范围: {'是' if result['in_standard_range'] else '否'}")
                output_lines.append(f"fastboot stage {result['s_prime_hex']}")
        return "\n".join(output_lines)

    def generate_summary_report(self, results: List[Dict]) -> str:
        output_lines = []
        output_lines.append("=" * 80)
        output_lines.append("RSA签名验证摘要报告")
        output_lines.append("=" * 80)
        if self.N_hex:
            output_lines.append(f"公钥模数 N (前64位): {self.N_hex[:64]}...")
        if self.S_hex:
            output_lines.append(f"原始签名 S (前64位): {self.S_hex[:64]}...")
        total_codes = len(results)
        valid_codes = len([r for r in results if r['in_standard_range']])
        invalid_codes = total_codes - valid_codes
        output_lines.append(f"\n统计信息:")
        output_lines.append(f"总测试签名数: {total_codes}")
        output_lines.append(f"在标准范围内: {valid_codes}")
        output_lines.append(f"超出标准范围: {invalid_codes}")
        all_pass = all(r['matches_original'] for r in results)
        output_lines.append(f"所有签名数学验证通过: {all_pass}")
        output_lines.append(f"\n理论分析:")
        output_lines.append("1. 数学定理: 对于任意整数k，S' = S + k*N 满足")
        output_lines.append("   pow(S', e, N) = pow(S, e, N)")
        output_lines.append("2. 实现要求: 标准RSA要求 0 ≤ 签名 < N")
        output_lines.append("3. 设备兼容性: 取决于是否检查签名范围")
        return "\n".join(output_lines)

def interactive_mode():
    print("=" * 80)
    print("RSA签名验证工具 - 交互模式")
    print("=" * 80)
    validator = RSAValidator()
    n_hex = input("请输入RSA公钥模数N（十六进制）: ").strip()
    if n_hex:
        validator.N = int(n_hex, 16)
        validator.N_hex = n_hex.upper()
    s_hex = input("请输入RSA签名S（十六进制）: ").strip()
    if s_hex:
        validator.S = int(s_hex, 16)
        validator.S_hex = s_hex.upper()
    length_check = validator.validate_input_lengths()
    print(f"\n输入验证:")
    print(f"N长度: {length_check.get('N_length', 'N/A')} 字符, 有效: {length_check.get('N_valid', False)}")
    print(f"S长度: {length_check.get('S_length', 'N/A')} 字符, 有效: {length_check.get('S_valid', False)}")
    print("\n生成变体签名...")
    results = validator.generate_variant_signatures()
    print(validator.format_for_fastboot(results))
    print(validator.generate_summary_report(results))
    return validator, results

def direct_mode(n_hex: str, s_hex: str):
    print("=" * 80)
    print("RSA签名验证工具 - 直接模式")
    print("=" * 80)
    validator = RSAValidator(n_hex, s_hex)
    length_check = validator.validate_input_lengths()
    print("输入数据:")
    print(f"N: ...")
    print(f"S: ...")
    print(f"N长度验证: {length_check.get('N_valid', False)}")
    print(f"S长度验证: {length_check.get('S_valid', False)}")
    print("\n生成变体签名...")
    results = validator.generate_variant_signatures()
    print(validator.format_for_fastboot(results))
    print(validator.generate_summary_report(results))
    return validator, results

def main():
    print("选择运行模式:")
    print("1. 交互模式 (手动输入)")
    print("2. 直接模式 (请手动修改代码内N_HEX/S_HEX)")
    print("3. 退出")
    choice = input("\n请输入选择 (1/2/3): ").strip()
    if choice == "1":
        interactive_mode()
    elif choice == "2":
        N_HEX = input("请输入默认N (十六进制): ").strip()
        S_HEX = input("请输入默认S (十六进制): ").strip()
        if N_HEX and S_HEX:
            direct_mode(N_HEX, S_HEX)
        else:
            print("N或S为空，退出")
    elif choice == "3":
        print("退出程序")
    else:
        print("无效选择")

if __name__ == "__main__":
    main()
